<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>DDT_CHS_Dropdown-validation_Testsuite</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>c4d21214-3980-42e1-b6df-1e6a6ac657e5</testSuiteGuid>
   <testCaseLink>
      <guid>4f7b7d69-8cad-4fd4-8ec8-f6f6dc3c96dd</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Data - Driven_testing/TC_Validation_Cura_Dropdown_Excel_001</testCaseId>
      <testDataLink>
         <combinationType>ONE</combinationType>
         <id>08056116-317d-4251-9d91-47aafcf52696</id>
         <iterationEntity>
            <iterationType>ALL</iterationType>
            <value></value>
         </iterationEntity>
         <testDataId>Data Files/DDT_CHS_TestData/CHS_TestData_excel_dropdown</testDataId>
      </testDataLink>
      <usingDataBindingAtTestSuiteLevel>true</usingDataBindingAtTestSuiteLevel>
      <variableLink>
         <testDataLinkId>08056116-317d-4251-9d91-47aafcf52696</testDataLinkId>
         <type>DATA_COLUMN</type>
         <value>dropdownElement</value>
         <variableId>ba6857a1-c501-4eca-8459-c2a6c6f8ab99</variableId>
      </variableLink>
   </testCaseLink>
</TestSuiteEntity>
