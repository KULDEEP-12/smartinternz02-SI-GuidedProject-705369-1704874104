import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

//open browser
WebUI.openBrowser('')

//navigate the URL
WebUI.navigateToUrl('https://katalon-demo-cura.herokuapp.com/')

//maximize the window
WebUI.maximizeWindow()

//get the URL
String url = WebUI.getUrl()

System.out.println(url)

//get window index
System.out.println(WebUI.getWindowIndex())

//get window title
System.out.println(WebUI.getWindowTitle())

WebUI.navigateToUrl('https://www.hdfcbank.com/')

System.out.println(WebUI.getWindowIndex())

WebUI.back()

int windex = WebUI.getWindowIndex()
System.out.println(windex)

String wtitle = WebUI.getWindowTitle()


System.out.println(wtitle)

WebUI.delay(3)

WebUI.forward()



WebUI.navigateToUrl('https://smartinternz.com/')
//WebUI.click(findTestObject('Object Repository/Manual_mode_Login/Page_Hardik Airy - Quora/span_Hardik Airy'))
WebUI.click(findTestObject('Object Repository/Smartinternz_OR/Page_SmartInternz/a_Externships'))

System.out.println(WebUI.getWindowTitle())

WebUI.switchToWindowIndex(1)
System.out.println(WebUI.getWindowIndex())









WebUI.closeBrowser()


